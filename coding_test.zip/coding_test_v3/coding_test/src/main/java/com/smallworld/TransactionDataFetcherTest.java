package com.smallworld;

import com.smallworld.data.Transaction;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import java.util.*;

public class TransactionDataFetcherTest {

    /**
     * Returns the sum of the amounts of all transactions
     */

    @Test
    public void testGetTotalTransactionAmount() {
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        double totalAmount = dataFetcher.getTotalTransactionAmount(transactions);

        // Assert
        Assertions.assertEquals(730.5999999999999, totalAmount);
    }

    @Test
    public void testGetTotalTransactionAmountSentBy() {
        // Arrange
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelbys", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 151.2, "Tom Shel", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        double totalAmount = dataFetcher.getTotalTransactionAmountSentBy(transactions, "Tom Shel");

        // Assert
        Assertions.assertEquals(151.2, totalAmount);
    }

    @Test
    public void testGetMaxTransactionAmount() {
        // Arrange
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150000.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        double maxAmount = dataFetcher.getMaxTransactionAmount(transactions);

        // Assert
        Assertions.assertEquals(150000.2, maxAmount);
    }

    @Test
    public void testCountUniqueClients() {
        // Arrange
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        long uniqueClients = dataFetcher.countUniqueClients(transactions);

        // Assert
        Assert.assertEquals(3, uniqueClients);
    }

    @Test
    public void testHasOpenComplianceIssues() {
        // Arrange
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        boolean hasOpenIssues = dataFetcher.hasOpenComplianceIssues(transactions, "Tom Shelby");

        // Assert
        Assert.assertTrue(hasOpenIssues);
    }



    @Test
    public void testGetTransactionsByBeneficiaryName() {
        // Create a list of transactions from the provided JSON data
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));

        // Calculate the expected map of transactions by beneficiary name
        Map<String, List<Transaction>> expectedTransactionsByBeneficiary = new HashMap<>();
        expectedTransactionsByBeneficiary.put("Alfie Solomons", List.of(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering")));

        // Call the method under test
        Map<String, List<Transaction>> actualTransactionsByBeneficiary = TransactionDataFetcher.getTransactionsByBeneficiaryName(transactions);

        // Assert that the actual map of transactions by beneficiary name matches the expected map
        Assertions.assertEquals(expectedTransactionsByBeneficiary, actualTransactionsByBeneficiary);
    }


    @Test
    public void testGetUnsolvedIssueIds() {
        // Create a list of transactions from the provided JSON data
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));
        transactions.add(new Transaction(96132456, 67.8, "Aunt Polly", 34, "Aberama Gold", 58, null, true, null));
        transactions.add(new Transaction(5465465, 985.0, "Arthur Shelby", 60, "Ben Younger", 47, 15, false, "Something's fishy"));
        transactions.add(new Transaction(1651665, 97.66, "Tom Shelby", 22, "Oswald Mosley", 37, 65, true, "Never gonna let you down"));
        transactions.add(new Transaction(6516461, 33.22, "Aunt Polly", 34, "MacTavern", 30, null, true, null));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 54, false, "Something ain't right"));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 78, true, "Never gonna run around and desert you"));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 99, false, "Don't let this transaction happen"));
        transactions.add(new Transaction(36448252, 154.15, "Billy Kimber", 58, "Winston Churchill", 48, null, true, null));
        transactions.add(new Transaction(645645111, 215.17, "Billy Kimber", 58, "Major Campbell", 41, null, true, null));
        transactions.add(new Transaction(45431585, 89.77, "Billy Kimber", 58, "Luca Changretta", 46, null, true, null));


        // Calculate the expected list of unsolved issue IDs
        List<Integer> expectedOpenIssueIds = new ArrayList<>();
        expectedOpenIssueIds.add(1);
        expectedOpenIssueIds.add(3);

        // Call the method under test
        List<Integer> actualOpenIssueIds = TransactionDataFetcher.getUnsolvedIssueIds(transactions);

        // Assert that the actual list of unsolved issue IDs matches the expected list
        Assertions.assertEquals(expectedOpenIssueIds, actualOpenIssueIds);
    }



    @Test
    public void testGetAllSolvedIssueMessages() {
        // Create a list of transactions from the provided JSON data
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));
        transactions.add(new Transaction(96132456, 67.8, "Aunt Polly", 34, "Aberama Gold", 58, null, true, null));
        transactions.add(new Transaction(5465465, 985.0, "Arthur Shelby", 60, "Ben Younger", 47, 15, false, "Something's fishy"));
        transactions.add(new Transaction(1651665, 97.66, "Tom Shelby", 22, "Oswald Mosley", 37, 65, true, "Never gonna let you down"));
        transactions.add(new Transaction(6516461, 33.22, "Aunt Polly", 34, "MacTavern", 30, null, true, null));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 54, false, "Something ain't right"));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 78, true, "Never gonna run around and desert you"));
        transactions.add(new Transaction(32612651, 666.0, "Grace Burgess", 31, "Michael Gray", 58, 99, false, "Don't let this transaction happen"));
        transactions.add(new Transaction(36448252, 154.15, "Billy Kimber", 58, "Winston Churchill", 48, null, true, null));
        transactions.add(new Transaction(645645111, 215.17, "Billy Kimber", 58, "Major Campbell", 41, null, true, null));
        transactions.add(new Transaction(45431585, 89.77, "Billy Kimber", 58, "Luca Changretta", 46, null, true, null));

        // Calculate the expected list of solved issue messages
        List<String> expectedSolvedIssueMessages = new ArrayList<>();
        expectedSolvedIssueMessages.add("Never gonna give you up");
        expectedSolvedIssueMessages.add("Never gonna let you down");
        expectedSolvedIssueMessages.add("Never gonna run around and desert you");

        // Call the method under test
        List<String> actualSolvedIssueMessages = TransactionDataFetcher.getAllSolvedIssueMessages(transactions);

        // Assert that the actual list of solved issue messages matches the expected list
        Assertions.assertEquals(expectedSolvedIssueMessages, actualSolvedIssueMessages);
    }


    @Test
    public void testGetTopSender() {
        // Arrange
        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150000.2, "Mike Johnson", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        TransactionDataFetcher dataFetcher = new TransactionDataFetcher();

        // Act
        Optional<String> topSender = dataFetcher.getTopSender(transactions);

        // Assert
        Assert.assertEquals("Mike Johnson", topSender.orElse(""));
    }
}
