package com.smallworld;

import com.smallworld.data.Transaction;

import java.util.*;

public class TransactionDataFetcher {
    /**
     * Returns the sum of the amounts of all transactions
     */
    public static double getTotalTransactionAmount(List<Transaction> transactions) {
        double totalAmount = 0.0;
        for (Transaction transaction : transactions) {
            totalAmount += transaction.getAmount();
        }
        return totalAmount;
    }


    /**
     * Returns the sum of the amounts of all transactions sent by the specified client
     */

    public static double getTotalTransactionAmountSentBy(List<Transaction> transactions, String clientName) {
        double totalAmount = 0.0;
        for (Transaction transaction : transactions) {
            if (transaction.getSenderFullName().equals(clientName)) {
                totalAmount += transaction.getAmount();
            }
        }
        return totalAmount;
    }

    /**
     * Returns the highest transaction amount
     */

    public static double getMaxTransactionAmount(List<Transaction> transactions) {
        double highestAmount = Double.MIN_VALUE;

        for (Transaction transaction : transactions) {
            if (transaction.getAmount() > highestAmount) {
                highestAmount = transaction.getAmount();
            }
        }
        return highestAmount;
    }


    /**
     * Counts the number of unique clients that sent or received a transaction
     */
    public static long countUniqueClients(List<Transaction> transactions) {
        List<String> uniqueClients = new ArrayList<>();

        for (Transaction transaction : transactions) {
            String sender = transaction.getSenderFullName();
            String beneficiary = transaction.getBeneficiaryFullName();

            if (!uniqueClients.contains(sender)) {
                uniqueClients.add(sender);
            }
            if (!uniqueClients.contains(beneficiary)) {
                uniqueClients.add(beneficiary);
            }
        }

        return uniqueClients.size();
    }

    /**
     * Returns whether a client (sender or beneficiary) has at least one transaction with a compliance
     * issue that has not been solved
     */

    public static boolean hasOpenComplianceIssues(List<Transaction> transactions, String clientName) {
        for (Transaction transaction : transactions) {
            if (transaction.getSenderFullName().equals(clientName) || transaction.getBeneficiaryFullName().equals(clientName)) {
                if (!transaction.isIssueSolved()) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Returns all transactions indexed by beneficiary name
     */

    public static Map<String, List<Transaction>> getTransactionsByBeneficiaryName(List<Transaction> transactions) {
        Map<String, List<Transaction>> transactionsByBeneficiary = new HashMap<>();

        for (Transaction transaction : transactions) {
            String beneficiary = transaction.getBeneficiaryFullName();
            List<Transaction> beneficiaryTransactions = transactionsByBeneficiary.getOrDefault(beneficiary, new ArrayList<>());
            beneficiaryTransactions.add(transaction);
            transactionsByBeneficiary.put(beneficiary, beneficiaryTransactions);
        }

        return transactionsByBeneficiary;
    }

    /**
     * Returns the identifiers of all open compliance issues
     */

    public static List<Integer> getUnsolvedIssueIds(List<Transaction> transactions) {
        List<Integer> openIssueIds = new ArrayList<>();

        for (Transaction transaction : transactions) {
            if (!transaction.isIssueSolved()) {
                Integer issueId = transaction.getIssueId();
                if (issueId != null) {
                    openIssueIds.add(issueId);
                }
            }
        }

        return openIssueIds;
    }


    /**
     * Returns a list of all solved issue messages
     */

    public static List<String> getAllSolvedIssueMessages(List<Transaction> transactions) {
        List<String> solvedIssueMessages = new ArrayList<>();

        for (Transaction transaction : transactions) {
            if (transaction.isIssueSolved()) {
                String issueMessage = transaction.getIssueMessage();
                if (issueMessage != null) {
                    solvedIssueMessages.add(issueMessage);
                }
            }
        }
        return solvedIssueMessages;
    }


    /**
     * Returns the senderFullName of the sender with the most total sent amount
     */

    public static Optional<String> getTopSender(List<Transaction> transactions) {
        Map<String, Double> senderTotalAmounts = new HashMap<>();

        for (Transaction transaction : transactions) {
            String senderFullName = transaction.getSenderFullName();
            double amount = transaction.getAmount();

            // Update the total amount for the sender
            senderTotalAmounts.put(senderFullName, senderTotalAmounts.getOrDefault(senderFullName, 0.0) + amount);
        }

        String senderWithMostSentAmount = null;
        double mostSentAmount = 0.0;
        for (Map.Entry<String, Double> entry : senderTotalAmounts.entrySet()) {
            String senderFullName = entry.getKey();
            double sentAmount = entry.getValue();

            // Check if the current sender has sent the most amount so far
            if (sentAmount > mostSentAmount) {
                mostSentAmount = sentAmount;
                senderWithMostSentAmount = senderFullName;
            }
        }
        return Optional.ofNullable(senderWithMostSentAmount);
    }

    /**
     * Returns the 3 transactions with the highest amount sorted by amount descending
     */


    /*    ONLY FOR TESTING

    public static void main(String[] args) {

        // Create a list of Transaction objects

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(new Transaction(663458, 430.2, "Tom Shelby", 22, "Alfie Solomons", 33, 1, false, "Looks like money laundering"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 2, true, "Never gonna give you up"));
        transactions.add(new Transaction(1284564, 150.2, "Tom Shelby", 22, "Arthur Shelby", 60, 3, false, "Looks like money laundering"));

        // Add more transactions...

        // Returns the sum of the amounts of all transactions
        double totalAmount=getTotalTransactionAmount(transactions);
        System.out.println("total AMOUNT :"+totalAmount);


        // Returns the sum of the amounts of all transactions sent by the specified client
        String clientName = "Tom Shelby";
        double totalAmountSentBy = getTotalTransactionAmountSentBy(transactions, clientName);
        System.out.println("Total Transaction Amount sent by " + clientName + ": " + totalAmountSentBy);


        //  Returns the highest transaction amount
        double maxAmount = getMaxTransactionAmount(transactions);
        System.out.println("Max Transaction Amount: " + maxAmount);


        //  Counts the number of unique clients that sent or received a transaction
        long uniqueClientsCount = countUniqueClients(transactions);
        System.out.println("Unique Clients Count: " + uniqueClientsCount);


        // Returns whether a client (sender or beneficiary) has at least one transaction with a compliance
        // issue that has not been solved
        boolean hasUnresolvedIssue = hasOpenComplianceIssues(transactions, clientName);
        if (hasUnresolvedIssue) {
            System.out.println(clientName + " has at least one transaction with an unresolved compliance issue.");
        } else {
            System.out.println(clientName + " does not have any transaction with an unresolved compliance issue.");
        }


        // Returns all transactions indexed by beneficiary name
        Map<String, List<Transaction>> transactionsByBeneficiary = getTransactionsByBeneficiaryName(transactions);
        for (Map.Entry<String, List<Transaction>> entry : transactionsByBeneficiary.entrySet()) {
            String beneficiary = entry.getKey();
            List<Transaction> beneficiaryTransactions = entry.getValue();
            System.out.println("Beneficiary: " + beneficiary);
            System.out.println("Transactions: ");
            for (Transaction transaction : beneficiaryTransactions) {
                System.out.println(transaction.toString());
            }
            System.out.println();
        }


        // Returns the identifiers of all open compliance issues
        List<Integer> openIssueIds = getUnsolvedIssueIds(transactions);
        System.out.println("Open Compliance Issue IDs: ");
        for (Integer issueId : openIssueIds) {
            System.out.println(issueId);
        }


        // Returns a list of all solved issue messages
        List<String> solvedIssueMessages = getAllSolvedIssueMessages(transactions);
        System.out.println("solvedIssueMessages: ");
        for (String messages : solvedIssueMessages) {
            System.out.println(messages);
        }



        // Returns the senderFullName of the sender with the most total sent amount
        Optional<String> senderWithMostSentAmount = getTopSender(transactions);
        if (senderWithMostSentAmount.isPresent()) {
            String senderFullName = senderWithMostSentAmount.get();
            System.out.println("Sender with the most total sent amount: " + senderFullName);
        } else {
            System.out.println("No sender has any transactions.");
        }
    }

 */

}


